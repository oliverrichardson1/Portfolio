import argparse
import tkinter as tk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import (
    FigureCanvasTkAgg, NavigationToolbar2Tk)
import matplotlib.animation as animation
from pandas import read_csv


class Window(tk.Frame):

    def __init__(self, master=None):
        tk.Frame.__init__(self, master)
        self.index = 0
        self.reset_checker = 0
        self.max_ms_render = 1000
        self.master = master
        self.init_window()

    def init_window(self):
        filename = "bursts1.csv"

        # # --Argument Parser--
        parser = argparse.ArgumentParser(description='Select Data', prog="SGR.py",
                                         epilog="If no columns are specified, will try and use default ones")
        #
        # # --File arg
        parser.add_argument("-f", help="File to read data from")

        args = parser.parse_args()

        if args.f:
            filename = args.f

        # preparing the data to be graphed
        df = read_csv(filename)
        df = df.dropna()  # drop all rows with empty fields
        df = df[
            (df[" Burst Type Enum"] != 0) | (df[" Burst Type Enum"] != 3)]  # drop all rows with a burst enum of 0 or 3
        df = df[df[" Average Magnitude"] != " -nan"]  # drop all rows that contain -nan
        end_time = df[" Start Time"] + df[" Duration"]  # create the variable endtime to get burst width
        df["End Time"] = end_time
        sample_rate = df[" Sample Rate"].iloc[0]  # get the sample rate
        s_to_ms = 1000  # startime and endtime will be converted to seconds and then to milliseconds
        df["Start Time ms"] = (df[" Start Time"] / sample_rate) * s_to_ms
        df["End Time ms"] = (df["End Time"] / sample_rate) * s_to_ms

        start_time = list(df.iloc[:, 8])  # Start Time

        magnitude = list(df.iloc[:, 5])  # Average

        end_time = list(df.iloc[:, 9])  # Start Time + Duration

        burst_type = list(df.iloc[:, 1])  # Burst Type Enum
        fig, axs = plt.subplots(figsize=(15, 8))
        fig.patch.set_facecolor('lightgray')
        self.min_x = 0
        self.max_x = 1000
        axs.set_xlim([self.min_x, self.max_x])

        def animate(i):

            axs.clear()  # clear graph at the start of each frame
            print("length of list: ", len(end_time))

            if self.reset_checker == 0:
                self.reset_checker = end_time[self.index] % self.max_ms_render

            if len(end_time) - 1 == self.index:
                self.index = 0
                self.reset_checker = 0

            else:
                while self.reset_checker != 0 & self.index < len(end_time):
                    print(self.index)

                    x_start = start_time[self.index]
                    x_end = end_time[self.index]

                    if end_time[self.index] >= self.max_ms_render:
                        x_start = x_start % self.max_ms_render
                        x_end = x_end % self.max_ms_render

                    x_coords = [start_time[self.index], start_time[self.index], end_time[self.index],
                                end_time[self.index]]  # we get 4 different points for our
                    y_coords = [0, magnitude[self.index], magnitude[self.index], 0]  # x and y coords to render a burst

                    if self.reset_checker > end_time[self.index] % 1000:
                        print("resetting graph")
                        self.reset_checker = 0
                        break

                    self.reset_checker = end_time[self.index] % 1000

                    if end_time[self.index] >= 1000:
                        x_coords[0] = x_coords[0] % 1000
                        x_coords[1] = x_coords[1] % 1000
                        x_coords[2] = x_coords[2] % 1000
                        x_coords[3] = x_coords[3] % 1000

                    if burst_type[self.index] == 1:  # check signal type to colour coordinate

                        axs.plot(x_coords, y_coords, color="cyan")
                        axs.fill(x_coords, y_coords,
                                 "cyan")  # area between the current x and y coords are filled with a colour

                    elif burst_type[self.index] == 2:
                        axs.plot(x_coords, y_coords, color="limegreen")
                        axs.fill(x_coords, y_coords, "limegreen")

                    if len(end_time) -1 > self.index:
                        self.index = self.index + 1

                    else:
                        self.index = 0
                        break

        self.master.title("LTE Synchronisation Burst Graphing")
        self.pack(fill='both', expand=1)

        play = tk.PhotoImage(file='play.png')  # png image used as a play icon on Button btn
        pause = tk.PhotoImage(file='pause.png')  # png image used as a play icon on Button btn

        def play_pause_graph():  # updates Button btn to either pause or resume graphing, btn icon also changes
            if btn.image == pause:  # this is done by checking which icon is currently in use by btn.
                btn.config(image=play)  # btn is configured to have its icon changed
                btn.image = play
                # self.play_graph = False
                ani.pause()

            elif btn.image == play:
                btn.config(image=pause)
                btn.image = pause
                # self.play_graph = True
                ani.resume()

        btn = tk.Button(root, image=pause, width=40, height=32, command=play_pause_graph)
        btn.image = pause
        btn.pack()
        canvas = FigureCanvasTkAgg(fig, master=self.master)
        toolbar = NavigationToolbar2Tk(canvas, self.master)
        canvas.draw()

        # placing the canvas on the Tkinter window
        canvas.get_tk_widget().pack(expand=True)

        # creating the Matplotlib toolbar
        # toolbar = NavigationToolbar2Tk(canvas, self.master)
        toolbar.update()

        # placing the toolbar on the Tkinter window
        canvas.get_tk_widget().pack()

        ani = animation.FuncAnimation(fig, animate, interval=0.01, blit=False)  # Matplotlib graph animation function
        axs.set_ylabel("Average Magnitude", fontsize=14)
        axs.set_xlabel("Time (ms)", fontsize=14)


root = tk.Tk()
root.geometry("1250x750")
root.config(bg="Darkgray")
app = Window(root)
app.mainloop()
