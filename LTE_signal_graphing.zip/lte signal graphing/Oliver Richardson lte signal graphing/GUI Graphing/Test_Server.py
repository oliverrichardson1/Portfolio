import socket
import struct

# Define the format of the struct
fmt = struct.Struct('illlll')

HOST = ''
PORT = 1235
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen()

    print("Waiting for client...")
    conn, addr = s.accept()
    with conn:
        print("Client connected:", addr)

        data_bytes = conn.recv(4096)
        print(data_bytes)

data_list = [fmt.unpack_from(data_bytes, i) for i in range(0, len(data_bytes), fmt.size)]

# Print the received data
for data in data_list:
    print(data)
