#include <iostream>
#include <cmath>
#include <asio.hpp>

using asio::ip::tcp;

int main() {
	try {
		asio::io_service io_service;
		tcp::endpoint endpoint(tcp::v4(), 1234);
		tcp::acceptor acceptor(io_service, endpoint);
		tcp::iostream stream;
		acceptor.accept(*stream.rdbuf());

		tcp::iostream python_stream("localhost", "12345");

		float i, q;
		while (stream >> i >> q) {
			float amplitude = std::sqrt(i * i + q * q);
			python_stream << amplitude << std::endl;
		}
	}
	catch (std::exception& e) {
		std::cerr << e.what() << std::endl;
	}
}
