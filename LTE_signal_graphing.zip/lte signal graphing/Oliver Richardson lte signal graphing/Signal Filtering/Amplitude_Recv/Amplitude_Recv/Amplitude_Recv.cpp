#include <iostream>
#include <cmath>
#include <array>
#include <vector>
#include <string>
#include <deque>
#include <mutex>
#include <thread>
#ifdef _WIN32
#define _WIN32_WINNIT 0X0A00
#endif
#define ASIO_STANDALONE
#include <asio.hpp>

using asio::ip::tcp;

const int windowSize = 40;
long double averageSum = 0;
long double amplitudeThreshold = 0.00;
const int frameSize = 10000;
long sampleRate = 200000;
float thresholdMultiplier = 1;

struct Burst
{
    enum BurstType
    {
        SyncOnly,
        SyncAndBroadcast,
        Noise
    };
    BurstType type;
    long frameStartIndex;
    long burstStartIndex;
    long burstduration;
    long double averageMagnitude;
    long sampleRate;
};

std::string getBurstTypeStr(Burst::BurstType burstType)
{
    switch (burstType)
    {
    case Burst::BurstType::SyncOnly:
        return "SyncOnly";
        break;
    case Burst::BurstType::SyncAndBroadcast:
        return "SyncAndBroadcast";
        break;
    case Burst::BurstType::Noise:
        return "Noise";
        break;
    }
    return "Error";
}

void calculateAmplitude(std::vector<long double>& amplitudes, float i, float q) {
    long double amplitude = sqrt(pow(i, 2) + pow(q, 2));
    std::cout << "Amplitude: " << amplitude << std::endl;
    amplitudes.push_back(amplitude);

}

void calculateAverageAmplitude(std::vector<long double>& averagedAmplitudes, std::vector<long double> &amplitudes) {
    long double windowAverage = 0;
    long double windowTotal = 0;
    int numWindows = amplitudes.size() - windowSize - 1;

    for (int i = 0; i < numWindows; i++){

        for (int j = 0; j < windowSize; j++) {
            windowTotal = windowTotal + amplitudes[i+j];
        }
        
        windowAverage = windowTotal / windowSize;
        averagedAmplitudes[i] = windowAverage;
        averageSum = averageSum + windowAverage;

    }
    amplitudes.clear();
    amplitudeThreshold = thresholdMultiplier * (averageSum / sampleRate);
    //std::cout << "window average: " << windowAverage << std::endl;
    //averagedAmplitudes.push_back(windowAverage);
    //std::cout << "amplitudes size: " << amplitudes.size() << std::endl;
    //amplitudes.pop_front(); //pop amplitude at the front of the deque in order to move the sliding window along
    //std::cout << "amplitudes size: " << amplitudes.size() << std::endl;
}

void calculateDurations(int durationStarts[], int durationEnds[]) {

}

Burst::BurstType identifyBurstType(long duration) {

    if (duration >= 120 && duration <= 170) {
        return Burst::BurstType::SyncOnly;
    }
    else if (duration >= 400 && duration <= 499 /*&& averageMagnitude < 0.0000025*/) { // For when duration is not enough to distingush between bursts  
        return Burst::BurstType::SyncAndBroadcast;
    }
    else if (duration < 120 || duration > 499) {
        return Burst::BurstType::Noise;
    }
}

void identifyBursts(std::vector<long double>& averagedAmplitudes, std::vector<Burst>& bursts)
{
    bool burstIdentified = false;
    long double burstAmplitudeSum = 0, averageMagnitude;
    long startIndex, duration, midBurst, frameStart;

    Burst::BurstType type;
    for (long i = 0; i < averagedAmplitudes.size(); i++){

        std::cout << "i " << i << std::endl;
        if (burstIdentified)
        {
            //std::cout << "burst Identified!" << std::endl;
            burstAmplitudeSum += averagedAmplitudes[i];
            std::cout << "Current index " << i << std::endl;
            std::cout << "Amplitude Threshold " << amplitudeThreshold << std::endl;
            std::cout << "Current Amplitude" << averagedAmplitudes[i] << std::endl;

            if ((averagedAmplitudes[i] < amplitudeThreshold) && (burstIdentified == true))
            {
                duration = i - startIndex;
                std::cout << "Duration" << duration << std::endl;
                averageMagnitude = burstAmplitudeSum / (duration);
                type = identifyBurstType(duration);
                frameStart = 0;
            
                //if (type == Burst::BurstType::SyncOnly || type == Burst::BurstType::SyncAndBroadcast) {
                    bursts.emplace_back(Burst{ type, frameStart, startIndex, duration, averageMagnitude, sampleRate });
                //}
                burstIdentified = false;
                burstAmplitudeSum = 0;
            }
        }
        else if ((averagedAmplitudes[i] > amplitudeThreshold) && (!burstIdentified))
        {
            startIndex = i;
            std::cout << "Start index " << startIndex << std::endl;
            burstIdentified = true;
        }
    }
    averagedAmplitudes.clear();
}

int main() {

   // std::deque<long double> amplitudes, averagedAmplitudes;
    std::mutex amplitudesLock, averagesLock;
    std::vector<Burst> syncSignals;
    std::vector<long double> amplitudesCopy, amplitudes, averagedAmplitudes;

	try {
        // Create a TCP acceptor to listen for incoming connections
        asio::io_service io_service;
        tcp::acceptor acceptor(io_service, tcp::endpoint(tcp::v4(), 1234)); // Listen on port 1234
        std::cout << "TCP server created..." << std::endl;
        
        asio::io_service io_service_out;
        tcp::socket socket2(io_service_out);


        while (true) {
            // Wait for a new connection
            std::cout << "Waitng for client connection..." << std::endl;
            tcp::socket socket(io_service);
            acceptor.accept(socket);
            std::cout << "Client connected to server!" << std::endl;
            std::cout << "Attempting to connect to python server..." << std::endl;
            tcp::resolver resolver(io_service_out);
            asio::connect(socket2, resolver.resolve({ "localhost", "1235" }));
            std::cout << "Connected to python server!" << std::endl;



            // Read I and Q values from the socket continuously and calculate the amplitude
            while (true) {
                //copyAmplitudes.join();
                //findSignals.join();
                float i, q;
                asio::read(socket, asio::buffer(&i, sizeof(float)));
                std::cout << "i value: " << i << std::endl;
                asio::read(socket, asio::buffer(&q, sizeof(float)));
                std::cout << "q value: " << q << std::endl;

                calculateAmplitude(amplitudes, i, q);

            }

            // Close the socket
            socket.close();
        }

        return 0;

	}
	catch (std::exception& e) {
		std::cerr << e.what() << std::endl;
	}
}
