<----LTE Synchronisation Signal Filtering and Graphing Application Setup and Run Guid---->

1. GUI Graphing
the gui is made using python 3.9 and requires the following libraries are installed:
	tkinter
	matplotlib
	pandas
	
The can either be install using the command pip3 install [LIBARARY]
or and IDE such as pycharm community edition can istall the libraries for you.

to run simply type python3 GUI.py or double click the GUI.py file. The same applies for the TCP test server


2. Signal Filtering

This was written using C++17 in visual studio 2022 and requires the asio STANDALONE libary (not boost). The library will
have to be linked to the project which can be done by going to solution properties in visual studio and going VC++
directories, and then adding the asio library path to the include directories variable. The library has been included in
signal graphing/libs as it is free to distribute under it's license.

to run select either debug mode or release mode in visual studio (both will require asio to be linked separately)


3. GNU Radio Receiver

The GNU Radio Receiver requires GNU Radio to be installed, with this application specifically using the radio conda
windows version found here: https://github.com/ryanvolz/radioconda

launch GNU Radio companion and click open file and the selent .grc file, it should open up in GNU Radio Companion.

The GUI can be run on its own however to run the other components they should be run in this order: 
Test_server.py -> Amplitude_Recv-> spectrum analyser.grc

NOTE: Everything except the GUI/Graphing will require and USB SDR to run.



